<?php
/**
 * Auto-generated render file for home-banner
 */
$wrapper_classes = 'bf-block-' . esc_attr('home-banner');
?>
<div class="<?php echo $wrapper_classes; ?>">
<div class="repeater-gallery">
<?php echo esc_html($attributes['new_field_1'] ?? ''); ?>
    <div class="gallery-item">
        <img src="image-1.jpg" alt="Gallery Image 1">
    </div>
    <div class="gallery-item">
        <img src="image-2.jpg" alt="Gallery Image 2">
    </div>
    <div class="gallery-item">
        <img src="image-3.jpg" alt="Gallery Image 3">
    </div>
</div>

</div>