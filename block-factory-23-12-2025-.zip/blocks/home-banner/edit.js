// blocks/my-custom-block/edit.js (This is the template the script overwrites)
// This line handles all core block editing components (RichText, MediaUpload, etc.)
import { useBlockProps, InspectorControls, RichText, MediaUpload, MediaUploadCheck } from '@wordpress/block-editor'; 

// This line handles all standard UI components (TextControl, Button, PanelBody, etc.)
import { PanelBody, TextControl, Button } from '@wordpress/components';

const Edit = ( { attributes, setAttributes } ) => {
	const blockProps = useBlockProps();

	return (
		<div { ...blockProps }>
			
            <InspectorControls key="default_title-settings">
                <PanelBody title="Default Block Title Settings" initialOpen={true}>
                    <TextControl
                        label="Default Block Title"
                        value={ attributes.default_title }
                        onChange={ ( value ) => setAttributes( { default_title: value } ) }
                    />
                </PanelBody>
            </InspectorControls>
        

            <InspectorControls key="new_field_1-settings">
                <PanelBody title="New gallery Field Settings" initialOpen={true}>
                    <MediaUploadCheck>
                        <MediaUpload
                            onSelect={ ( media ) => setAttributes( { new_field_1: media } ) }
                            allowedTypes={ [ 'image' ] }
                            multiple={ true } // CRITICAL for gallery
                            value={ attributes.new_field_1 ? attributes.new_field_1.map( ( item ) => item.id ) : [] }
                            render={ ( { open } ) => (
                                <Button onClick={ open } isPrimary>
                                    { attributes.new_field_1 && attributes.new_field_1.length > 0 ? 'Edit Gallery (' + attributes.new_field_1.length + ')' : 'Create Gallery' }
                                </Button>
                            ) }
                        />
                    </MediaUploadCheck>
                    { attributes.new_field_1 && (
                        <div style={{ marginTop: '10px' }}>
                            {attributes.new_field_1.map((img, index) => (
                                <img key={index} src={img.url} style={{ width: '50px', height: '50px', objectFit: 'cover', margin: '5px' }} title={img.alt} />
                            ))}
                        </div>
                    )}
                </PanelBody>
            </InspectorControls>
        

			<RichText
				tagName="p"
				value={ attributes.message }
				allowedFormats={ [ 'core/bold', 'core/italic' ] }
				onChange={ ( message ) => setAttributes( { message } ) }
				placeholder="Write your Home Banner message here..."
			/>
		</div>
	);
};
export default Edit;