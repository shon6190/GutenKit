<?php return array('dependencies' => array('react-jsx-runtime'), 'version' => '7931d7c6bb8dd6ab6257');
